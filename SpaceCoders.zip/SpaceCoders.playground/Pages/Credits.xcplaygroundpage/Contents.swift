//: [Previous](@previous)

/*
 
  _____ _                 _
 |_   _| |__   __ _ _ __ | | _____
   | | | '_ \ / _` | '_ \| |/ / __|
   | | | | | | (_| | | | |   <\__ \
   |_| |_| |_|\__,_|_| |_|_|\_\___/
 
 for playing
 
  ____                          ____          _
 / ___| _ __   __ _  ___ ___   / ___|___   __| | ___ _ __ ___
 \___ \| '_ \ / _` |/ __/ _ \ | |   / _ \ / _` |/ _ \ '__/ __|
  ___) | |_) | (_| | (_|  __/ | |__| (_) | (_| |  __/ |  \__ \
 |____/| .__/ \__,_|\___\___|  \____\___/ \__,_|\___|_|  |___/
       |_|

 
 
 Developer, Designer, and Programmer: Ronak Shah
 
 Ship Art: Created by Doug McCoy
 
 Link: http://clipart-library.com/images/kcKboL5cj.jpg
 
 Enemy Art: Downloaded From Clker.com
 
 Link: http://www.clker.com/clipart-space-invaders.html
 
 Bullet: Created by Ronak Shah

 --> It's a rectangle, created using Paintbrush
 
 Source Code can be found online at github: https://github.com/ronakdev/spacecoders
*/